# -*- coding: utf-8 -*-


def is_numeric(input_str):
    """ 문자열 하나를 전달받아서, 문자열이 숫자면 True를, 아니면 False 를 반환하는 함수를 작성하자

        sample data: "555"
        expected output: True

        sample data: "a55"
        expected output: False
    """
    #여기 작성
    return


if __name__ == "__main__":
    pass

