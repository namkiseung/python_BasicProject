# -*- coding: utf-8 -*-


def get_values_in_dictionary(input_dict):
    """ 딕셔너리를 전달받아서, 밸류 리스트를 반환하는 함수를 작성하자
        
        sample data: {"year": 2017, "favorite": ["Chicken", "Pizza", "Zazangmyun", "Ramyun"], "phone": "01012345678"}
        expected output: ['01012345678', ['Chicken', 'Pizza', 'Zazangmyun', 'Ramyun'], 2017]

        sample data: {"key1": "green", "key2": "black"}
        expected output: ['black', 'green']
    """
    # 여기에 작성
    return


if __name__ == "__main__":
    pass

