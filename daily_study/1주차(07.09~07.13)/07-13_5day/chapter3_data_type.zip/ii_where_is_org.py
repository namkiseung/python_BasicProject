# -*- coding: utf-8 -*-


def where_is_org(input_list):
    """ 입력된 list에서 'org'가 몇번째에 있는지를 반환하는 함수를 작성해보자
        ! 'org' 가 반드시 포함돼 있어야 함

        sample data: ["co.kr", "com", "org", "net", "re", "ru"]
        expected output: 2
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass