# -*- coding: utf-8 -*-


def remove_key(input_dict, key_to_remove):
    """ dict형 변수 input_dict와 문자열 변수 key_to_remove 를 전달받아서
          input_dict에 key_to_remove에 해당하는 key가 있으면,
          그 키:값 쌍을 지우고 input_dict를 반환하는 함수를 작성하자
        
        sample data: {'a':1,'b':2,'c':3,'d':4}, 'b'
        expected output: {'a': 1, 'c': 3, 'd': 4}
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass

