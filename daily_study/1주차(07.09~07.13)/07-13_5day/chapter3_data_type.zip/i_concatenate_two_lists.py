# -*- coding: utf-8 -*-


def concatenate_two_lists(list1, list2):
    """ 두 개의 리스트를 전달받아서, 하나로 합쳐서 반환하는 함수를 작성해보자
        hint: extend 또는 +

        sample data: [10, 20, 30], [40, 50, 60]
        expected output : [40, 50, 60, 10, 20, 30]
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass

