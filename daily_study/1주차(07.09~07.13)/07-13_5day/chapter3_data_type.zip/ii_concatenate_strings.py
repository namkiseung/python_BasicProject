# -*- coding: utf-8 -*-


def concatenate_strings(input_list):
    """ 입력받은 문자열 리스트를 '-' 문자로 연결해서 반환하는 함수를 작성하자
        hint: join

        sample data: ['Red', 'White', 'Black'] 
        expected output: 'Red-White-Black'
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass

