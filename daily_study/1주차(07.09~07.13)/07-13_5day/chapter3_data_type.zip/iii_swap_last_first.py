# -*- coding: utf-8 -*-


def swap_last_first(input_list):
    """ 세개의 문자열을 요소로 갖는 list를 전달받아서, 첫번째와 세번째의 순서를 바꿔서 반환하는 함수를 작성해보자

        sample data: ["i2sec", "co", "kr"]
        expected output: ["kr", "co", "i2sec"]
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass