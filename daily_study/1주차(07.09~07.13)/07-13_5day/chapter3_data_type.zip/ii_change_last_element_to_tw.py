# -*- coding: utf-8 -*-


def change_last_element_to_tw(input_list):
    """ 마지막 요소를 'tw'로 변경해서 반환하는 함수를 작성해보자
        
        sample data: ["co.kr", "com", "org", "net", "re", "ru"]
        expected output: ["co.kr", "com", "org", "net", "re", "tw"]
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass