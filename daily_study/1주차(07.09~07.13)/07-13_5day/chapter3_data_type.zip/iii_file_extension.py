# -*- coding: utf-8 -*-


def file_extension(filename):
    """ 파일 이름을 전달받아서 확장자를 반환하는 함수를 작성하자

        sample data: python.exe
        expteted output: exe
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass

