# -*- coding: utf-8 -*-


def find_and_count(target_string, string_to_find):
    """ 문자열 두개 target_string, string_to_find 를 전달 받아서, 
          target_string에 string_to_find가 몇개 포함되어 있는지 그 개수를 반환하는 함수를 작성하자
        
        sample data: target_string="Google", string_to_find="o"
        expected output: 2

        sample data: 'fizzbuzz', 'z'
        expected output: 4
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass

