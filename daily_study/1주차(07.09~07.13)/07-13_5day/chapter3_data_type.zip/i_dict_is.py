# -*- coding: utf-8 -*-


def dict_is():
    """ 다음 문장에 A와 B에 들어갈 값을 보기에서 고르고 format 함수의 인자로 전달하자.
        dict는 {A:B} A와 B로 구성되어 있다.
    """
    nn = ''

    # 보기 1~4
    a1 = u"키, 값"
    a2 = u"Dict, 키"
    a3 = u"값, 키"
    a4 = u"값, Dict"

    msg = u"Dict 는 {}(으)로 구성되어 있다.".format(nn) # 여기에 작성! nn을 지우고 답이 될 변수 이름을 적으세요.
    return msg


if __name__ == "__main__":
    pass

