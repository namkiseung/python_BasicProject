# -*- coding: utf-8 -*-


def get_every_third_item(input_list):
    """ list를 전달받아서 세번째에 오는 요소들만 따로 목록으로 만들어 반환하는 함수를 작성하자
          (말로 설명이 어려우니 sample_data, expected_output을 보자)
        
        sample data: [1,2,3,4,5,6,7,8,9]
        expected output: [3,6,9]

        sample data: [10, 20, 30, 40, 50, 60, 70]
        expected output: [30, 60]
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass

