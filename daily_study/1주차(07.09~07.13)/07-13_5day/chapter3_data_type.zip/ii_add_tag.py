# -*- coding: utf-8 -*-


def add_tag(tag, data):
    """ 문자열을 두 개 tag, data 를 전달받아서, data를 tag 로 감싼 형태로 반환하는 함수를 작성하자.(sample 참조)
          (html 태그 형태인데, 나중에 많이 보게 될 것)

        sample data: tag="i", data="italic"
        expected output: "<i>italic</i>"

        sample data: tag="b", data="strong bold"
        expected output: "<b>strong bold</b>"
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass

