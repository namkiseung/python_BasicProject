# -*- coding: utf-8 -*-


def get_last_element(input_list):
    """ 마지막에 있는 있는 데이터를 반환하는 함수를 작성해보자
        hint: -(마이너스), 음수, 인덱싱
        
        sample data: ["co.kr", "com", "org", "net", "re", "ru"]
        expected output: "ru"
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass