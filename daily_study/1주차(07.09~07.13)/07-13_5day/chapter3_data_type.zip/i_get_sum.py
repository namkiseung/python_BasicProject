# -*- coding: utf-8 -*-


def get_sum(input_list):
    """ 정수들을 요소로 갖는 리스트를 전달받아서, 그 정수들의 총 합을 반환하는 함수를 작성해보자
        hint: sum

        sample data: [10,20,30]
        expected output: 60
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass