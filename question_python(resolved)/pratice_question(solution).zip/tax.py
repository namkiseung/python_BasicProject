# -*- coding: utf-8 -*-
import unittest
def tax_count(x, y, z):
    '''
    세금 

    16세에서 65세 사이의 그룹은 세금을 내야 한다
    소득이 20,000달러 미만인 사람은 20% 세금을 내야 하고, 그 외 사람은 50% 세금을 내야 한다.
    만약 이 사람들 중 아이가 있으면 10% 감세를 받을 수 있다.
    '''
    # 여기 작성
    sub_tax=0
    dis_tax=0
    xy=0
    age = x
    income=y
    if age > 15 and age < 66:
        #세금낸다
        if income < 20000:
        #20퍼 세금
            sub_tax = y * 0.2
        else:
            sub_tax = y * 0.5
        #50퍼 세금
        if z == "baby":
            dis_tax = y * 0.1
            #print "10% 감세 금액은 : ",dis_tax
    else:
        #세금 안낸다
        pass
    xy = y-sub_tax+dis_tax
    return xy 

# class TestCase(unittest.TestCase):
#     def test_tax(self):
#         self.assertEqual(tax(15), '')
#     pass

if __name__ == "__main__":
    #unittest.main()
    print tax_count(17, 14000, "baby")
    pass
    