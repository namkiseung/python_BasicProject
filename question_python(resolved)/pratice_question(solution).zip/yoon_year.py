# -*- coding: utf-8 -*-
import unittest
def yoou(num):
    year = num
    text = ""
    if year % 400 == 0:
        text = "yoon"
    elif year % 100 == 0:
        text = "common"
    elif year % 4 == 0::
        text = "yoon"
    return text

class TestCase(unittest.TestCase):
    def test_yoou(self):
        self.assertEqual(yoou(2100), 'common')
    pass

if __name__ == "__main__":
    unittest.main()
    #print yoou(2012)
    pass