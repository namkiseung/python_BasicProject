# -*- coding: utf-8 -*-


def get_3rd_element(input_list):
    """ 2번째에 있는 요소를 리턴하는 함수를 작성해보자

        sample data: list_sample_a = ["co.kr", "com", "org", "net", "re", "ru"]
        expected output: "org"
    """
    # 여기 작성
    list_sample_a = ["co.kr", "com", "org", "net", "re", "ru"]
    return list_sample_a[input_list]

if __name__ == "__main__":
    print(get_3rd_element(2))
    pass
