# -*- coding: utf-8 -*-




# list indexing
def get_1st_element(input_list):
    """ 0번째에 있는 값을 반환하는 함수를 작성해보자

        sample data: list_sample_a = ["co.kr", "com", "org", "net", "re", "ru"]
        expected output: "co.kr"
    """
    list_sample_a = ["co.kr", "com", "org", "net", "re", "ru"]
    
    # 여기 작성
    return list_sample_a[input_list]

if __name__ == "__main__":
    print(get_1st_element(0))
    pass
