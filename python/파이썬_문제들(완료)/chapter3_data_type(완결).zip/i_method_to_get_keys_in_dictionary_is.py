# -*- coding: utf-8 -*-


def method_to_get_keys_in_dictionary_is():
    """ 딕셔너리의 키를 얻는 메소드 이름은?  # 메소드는 함수랑 비슷한 거, 자세한 내용은 뒤에서 다룸
    """
    answer = "dict.keys()"   # 여기에 작성! nn을 지우고 메소드 이름을 적으세요
    return answer


if __name__ == "__main__":
    print('dict의 키를 얻는 메서드는?',method_to_get_keys_in_dictionary_is())
    pass

