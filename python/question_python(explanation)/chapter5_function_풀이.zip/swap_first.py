# -*- coding: utf-8 -*-



""" 문자열 하나를 전달받아, 첫 글자와 끝 글자를 서로 바꾼 후 반환하는 함수 swap_first를 작성하자

    sample in/out:
        swap_first("abcd") -> "dbca"
        swap_first("12345") -> "52341"
"""

def swap_first(s):
    r = s[-1] + s[1:-1] +  s[0]
    return r


if __name__ == "__main__":
    if swap_first("abcd") == "dbca":
        print "success"
    if swap_first("12345") == "52341":
        print "success"

