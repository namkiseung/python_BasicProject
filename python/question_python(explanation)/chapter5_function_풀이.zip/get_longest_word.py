# -*- coding: utf-8 -*-



""" 문자열 리스트를 전달받아, 가장 긴 문자열을 반환하는 함수 get_longest_word를 작성하자

    sample in/out:
        get_longest_word(['C', 'Web', 'python', 'linux']) -> 'python'
        get_longest_word(['google', 'apple', 'nokia', 'samsung']) -> 'samsung'
"""
def get_longest_word(s_list):
    # r = s_list[0]         # 1
    # rl = len(s_list[0])
    
    # for s in s_list[1:]:
    #     if rl < len(s):
    #         rl = len(s)
    #         r = s

    # r = max(s_list, key=len)      # 2

    s_list.sort(key=len)            # 3
    r = s_list[-1]
    return r

if __name__ == "__main__":
    print get_longest_word(['C', 'Web', 'python', 'linux'])# -> 'python'
    print get_longest_word(['google', 'apple', 'nokia', 'samsung'])# -> 'samsung'
    print get_longest_word(['google', 'apple', "harddistdrive", 'nokia', 'samsung', ])# -> 'samsung'

