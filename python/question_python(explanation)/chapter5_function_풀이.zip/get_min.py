# -*- coding: utf-8 -*-


""" 정수 두개를 가진 튜플들을 가진 리스트를 전달받아, 두 수의 차가 가장 작은 튜플을 반환하는 함수 get_min를 작성하자
    
    sample in/out:
        get_min([(1,2), (3,5), (100, 10)]) -> (1, 2)
        get_min([(1,10), (3,5), (100, 10)]) -> (3, 5)
"""

def f(x):
    return abs(x[0]-x[1])

def get_min(t_list):
    #t_list.sort(key=f)                             # key function 이용한 풀이
    t_list.sort(key= lambda x : abs(x[0]-x[1]) )    # key function 이용한 풀이 lambda 이용
    r = t_list[0]
    return r

if __name__ == "__main__":
    print get_min([(1,2), (3,5), (100, 10)])# -> (1, 2)
    print get_min([(1,10), (3,5), (100, 10)])# -> (3, 5)

