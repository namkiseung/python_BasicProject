# -*- coding: utf-8 -*-



""" 정수 n을 전달받고, n의 factorial 을 반환하는 함수 factorial를 작성하자

    sample in/out:
        factorial(5) -> 120
        factorial(1) -> 1
        factorial(10) -> 3628800
"""

def factorial(x):
    # r = 1
    # for i in range(1, x+1):
    #     r = r*i
    # return r
    if x==0:
        return 1
    return x * factorial(x-1)


if __name__ == "__main__":
    print factorial(5)