# -*- coding: utf-8 -*-


def print_dict(input_dict):
    """ 입력된 dict의 키와 값을 아래와 같이 문자열로 만들어 반환하는 함수를 작성하자

        sample in/out:
            print_dict({"ham":"yes", "egg":"yes", "spam":"no"}) -> "(1) egg -> yes\n(2) ham -> yes\n(3) spam -> no"
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass

