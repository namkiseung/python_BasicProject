# -*- coding: utf-8 -*-



""" 문자열 리스트를 전달받아, 가장 긴 문자열을 반환하는 함수 get_longest_word를 작성하자

    sample in/out:
        get_longest_word(['C', 'Web', 'python', 'linux']) -> 'python'
        get_longest_word(['google', 'apple', 'nokia', 'samsung']) -> 'samsung'
"""



if __name__ == "__main__":
    pass

