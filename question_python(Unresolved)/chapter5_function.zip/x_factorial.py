# -*- coding: utf-8 -*-



""" 정수 n을 전달받고, n의 factorial 을 반환하는 함수 factorial를 작성하자

    sample in/out:
        factorial(5) -> 120
        factorial(1) -> 1
        factorial(10) -> 3628800
"""

if __name__ == "__main__":
    pass