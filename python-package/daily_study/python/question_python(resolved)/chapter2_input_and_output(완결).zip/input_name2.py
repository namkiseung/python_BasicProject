# -*- coding: utf-8 -*-

def input_name2(name, age):
    """ 이름과 나이를 인자로 입력받고, "Hello "라는 인사와 함께 화면에 출력해봅시다
        !sample data: "ttamna", 23
        !output: Hello ttamna(23)
    """
    print 'Hello',name,"(",age,")"
    # 여기에 작성
    pass


if __name__ == "__main__":

    # 새로 작성, 주석 해제 등등 하면 됨(input 함수 사용)
    name = raw_input('what your name?')
    age = input('how old are you?')
    input_name2(name, age)