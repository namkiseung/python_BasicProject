# -*- coding: utf-8 -*-

def write_list(input_list):
    """ 전달받은 리스트를 파일에 저장하는 함수를 작성하자
        리스트의 각 요소는 개행으로 구분한다

        note: 저장되는 파일이름은 m_list.txt로 한다
    """
    # 여기 작성
    return


if __name__ == "__main__":
    pass