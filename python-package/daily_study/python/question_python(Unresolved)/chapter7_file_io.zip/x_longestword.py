# -*- coding: utf-8 -*-


def longest_word(filename):
    """ 전달받은 파일에서 가장 긴 단어를 문자열로 반환하는 함수를 작성하자
    """
    # 여기 작성
    return

if __name__ == "__main__":
    filename = ""
    print longest_word(filename)