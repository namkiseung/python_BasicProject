# -*- coding: utf-8 -*-

import unittest

def get_first_three(input_str):
    """ 입력된 문자의 첫 세글자를 반환하는 함수를 작성하자
        단, 입력된 문자열의 길이가 3이하면, 입력된 글자를 그대로 반환한다.
    """
    # 여기 작성
    return


class TestCase(unittest.TestCase):
    """  get_first_three 함수를 테스트하는 코드를 작성하자
    """
    pass


if __name__ == "__main__":
    unittest.main()