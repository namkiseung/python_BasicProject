# -*- coding: utf-8 -*-

import unittest

def is_all_the_same(input_list):
    """ 입력된 리스트의 요소들이 모두 같은 값이면 True를, 아니면 False를 반환하는 함수를 작성하자
    """
    # 여기 작성
    return


class TestCase(unittest.TestCase):
    """ is_all_the_same 함수를 테스트하는 코드를 작성하자
    """
    pass


if __name__ == "__main__":
    unittest.main()