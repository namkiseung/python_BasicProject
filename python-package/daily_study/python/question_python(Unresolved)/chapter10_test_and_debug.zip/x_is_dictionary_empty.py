# -*- coding: utf-8 -*-
import unittest

def is_empty(input_dict):
    """ 입력된 dict가 비어있으면 True를, 아니면 False를 반환하는 함수를 만들자.
    """
    # 여기 작성
    return


class DictionaryTest(unittest.TestCase):
    """ is_empty 함수를 테스트하는 코드를 작성해보자 """
    pass


if __name__ == "__main__":
    unittest.main()