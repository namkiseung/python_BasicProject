# -*- coding: utf-8 -*-

import unittest

def reverse_string(input_str):
    """ 입력된 문자열을 거꾸로 뒤집어(문자 순서 반대로) 반환하는 함수를 작성하자
    """
    # 여기 작성
    return


class TestCase(unittest.TestCase):
    """  reverse_string 함수를 테스트하는 코드를 작성하자
    """
    pass


if __name__ == "__main__":
    unittest.main()