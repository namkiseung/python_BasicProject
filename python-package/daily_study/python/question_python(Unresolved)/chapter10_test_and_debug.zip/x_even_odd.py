# -*- coding: utf-8 -*-

import unittest

def even_odd(input_list):
    """ 입력된 정수 리스트에서 짝수와 홀수 개수를 세어 튜플 형태로 반환하는 함수를 작성하자
    """
    cnt_even = cnt_odd = 0
    # 여기 작성
    return cnt_even, cnt_odd


class TestCase(unittest.TestCase):
    """  even_odd 함수를 테스트하는 코드를 작성하자
    """
    pass


if __name__ == "__main__":
    unittest.main()