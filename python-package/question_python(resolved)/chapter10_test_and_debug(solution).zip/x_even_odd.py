# -*- coding: utf-8 -*-

import unittest

def even_odd(input_list):
    """ 입력된 정수 리스트에서 짝수와 홀수 개수를 세어 튜플 형태로 반환하는 함수를 작성하자
    """
    cnt_even = cnt_odd = 0
    # 여기 작성
    for x in input_list:
        if x % 2 == 0:
            cnt_even += 1
        else:
            cnt_odd += 1
    return cnt_even, cnt_odd


class TestCase(unittest.TestCase):
    """  even_odd 함수를 테스트하는 코드를 작성하자
    """
    def test_even_odd(self):
        a=[1,2,3,4,5]
        b=[1,1,1,1,1]
        self.assertEqual(even_odd(b), (1, 5))
    pass


if __name__ == "__main__":
    unittest.main()