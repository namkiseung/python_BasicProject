# -*- coding: utf-8 -*-

import unittest

def get_first_three(input_str):
    """ 입력된 문자의 첫 세글자를 반환하는 함수를 작성하자
        단, 입력된 문자열의 길이가 3이하면, 입력된 글자를 그대로 반환한다.
    """
    # 여기 작성
    if len(input_str) < 3:
        return input_str
    return input_str[0:3]


class TestCase(unittest.TestCase):
    """  get_first_three 함수를 테스트하는 코드를 작성하자
    """
    def test_get_first_three(self):
        a=[1,2,3,4,5]
        b=[1,1,1,1,1]
        self.assertEqual(get_first_three("namkiseung"), "nam")
    pass


if __name__ == "__main__":
    unittest.main()