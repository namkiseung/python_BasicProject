# -*- coding: utf-8 -*-

import unittest

def is_all_the_same(input_list):
    """ 입력된 리스트의 요소들이 모두 같은 값이면 True를, 아니면 False를 반환하는 함수를 작성하자
    """
    # 여기 작성
    x=input_list[0]
    cnt = 0
    for i in input_list: 
        if str(x) in str(i):
            cnt += 1
        if cnt == len(input_list):
            return True

    return False


class TestCase(unittest.TestCase):
    """ is_all_the_same 함수를 테스트하는 코드를 작성하자
    """
    def test_is_all_the_same(self):
        a=[1,2,3,4,5]
        b=[1,1,1,1,1]
        self.assertEqual(is_all_the_same(b), True)
    
    pass


if __name__ == "__main__":
    
    # 
    # print is_all_the_same(a)
    # print is_all_the_same(b)
    unittest.main()